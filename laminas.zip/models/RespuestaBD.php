<?php
class RespuestaBD
{

    // database connection and table name
    public $exito;
    public $mensaje;
    public $registros=array();
    public $valor;
   
    


}
